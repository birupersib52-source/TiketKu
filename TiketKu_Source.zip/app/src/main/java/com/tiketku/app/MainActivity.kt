package com.tiketku.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Flight(val airline:String,val code:String,val from:String,val to:String,val depart:String,val arrive:String,val price:String,val duration:String)

private val Blue=Color(0xFF0B5FFF)
private val flights=listOf(
 Flight("Garuda Indonesia","GA 188","CGK","DPS","08:00","10:50","Rp 1.250.000","1j 50m"),
 Flight("Lion Air","JT 12","CGK","DPS","11:20","14:10","Rp 820.000","1j 50m"),
 Flight("Citilink","QG 680","CGK","DPS","15:00","17:55","Rp 940.000","1j 55m"),
 Flight("Batik Air","ID 6502","CGK","DPS","19:30","22:20","Rp 1.080.000","1j 50m")
)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{App()}}
}

@Composable fun App(){
 var page by remember{mutableStateOf("home")}
 var selected by remember{mutableStateOf<Flight?>(null)}
 MaterialTheme(colorScheme=lightColorScheme(primary=Blue,background=Color(0xFFF5F7FB))){
  when(page){
   "home"->Home{page="search"}
   "search"->Search({page="home"}){selected=it;page="passenger"}
   "passenger"->Passenger(selected!!,{page="search"}){page="payment"}
   "payment"->Payment(selected!!,{page="passenger"}){page="ticket"}
   else->Ticket(selected!!){page="home"}
  }
 }
}

@Composable fun Top(title:String,back:()->Unit){
 Row(Modifier.fillMaxWidth().background(Blue).padding(12.dp),verticalAlignment=Alignment.CenterVertically){
  IconButton(back){Icon(Icons.Default.ArrowBack,null,tint=Color.White)}
  Text(title,color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold)
 }
}

@Composable fun Home(go:()->Unit){
 Scaffold(bottomBar={NavigationBar{
  NavigationBarItem(true,{},icon={Icon(Icons.Default.Home,null)},label={Text("Beranda")})
  NavigationBarItem(false,{},icon={Icon(Icons.Default.ConfirmationNumber,null)},label={Text("Pesanan")})
  NavigationBarItem(false,{},icon={Icon(Icons.Default.Person,null)},label={Text("Profil")})
 }}){p->
  LazyColumn(Modifier.fillMaxSize().padding(p).padding(18.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
   item{Text("TiketKu",fontSize=32.sp,fontWeight=FontWeight.ExtraBold,color=Blue);Text("Terbang lebih mudah.",color=Color.Gray)}
   item{Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=Blue)){
    Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
     Text("Cari penerbangan",color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold)
     OutlinedButton(onClick=go,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.outlinedButtonColors(containerColor=Color.White,contentColor=Blue)){Text("CGK  →  DPS   •   Pilih tanggal")}
     Button(onClick=go,modifier=Modifier.fillMaxWidth()){Text("Cari Penerbangan")}
    }
   }}
   item{Text("Promo hari ini",fontSize=20.sp,fontWeight=FontWeight.Bold)}
   item{Card(shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(18.dp)){Text("Diskon penerbangan",fontSize=18.sp,fontWeight=FontWeight.Bold);Text("Harga contoh untuk demo aplikasi.",color=Color.Gray)}}}
  }
 }
}

@Composable fun Search(back:()->Unit,pick:(Flight)->Unit){
 Column{Top("Pilih penerbangan",back);LazyColumn(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  items(flights){f->Card(shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(f.airline,fontWeight=FontWeight.Bold);Text(f.price,color=Blue,fontWeight=FontWeight.Bold)}
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("${f.depart}  ${f.from}",fontSize=18.sp);Text(f.duration,color=Color.Gray);Text("${f.arrive}  ${f.to}",fontSize=18.sp)}
   Text(f.code,color=Color.Gray)
   Button(onClick={pick(f)},modifier=Modifier.fillMaxWidth()){Text("Pilih")}
  }}}
 }}
}

@Composable fun Passenger(f:Flight,back:()->Unit,next:()->Unit){
 var name by remember{mutableStateOf("")}; var phone by remember{mutableStateOf("")}
 Column{Top("Data penumpang",back);Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
  Text("${f.airline} • ${f.code}",fontWeight=FontWeight.Bold,fontSize=18.sp)
  OutlinedTextField(name,{name=it},label={Text("Nama lengkap")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(phone,{phone=it},label={Text("Nomor HP")},modifier=Modifier.fillMaxWidth())
  Text("Data akan digunakan untuk penerbitan tiket.",color=Color.Gray,fontSize=13.sp)
  Button(onClick=next,enabled=name.isNotBlank()&&phone.isNotBlank(),modifier=Modifier.fillMaxWidth()){Text("Lanjut Pembayaran")}
 }}
}

@Composable fun Payment(f:Flight,back:()->Unit,done:()->Unit){
 Column{Top("Pembayaran",back);Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
  Card(shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(18.dp)){Text("Total pembayaran",color=Color.Gray);Text(f.price,fontSize=28.sp,fontWeight=FontWeight.ExtraBold,color=Blue);Text("${f.airline} • ${f.from} → ${f.to}")}}
  Text("Metode pembayaran",fontSize=20.sp,fontWeight=FontWeight.Bold)
  Card(shape=RoundedCornerShape(16.dp)){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.QrCode2,null,tint=Blue,modifier=Modifier.size(38.dp));Spacer(Modifier.width(14.dp));Column{Text("QRIS",fontWeight=FontWeight.Bold);Text("Pembayaran aman melalui payment gateway",color=Color.Gray,fontSize=13.sp)}}}
  Text("Mode demo: QRIS belum terhubung ke rekening nyata.",color=Color.Gray,fontSize=13.sp)
  Button(onClick=done,modifier=Modifier.fillMaxWidth()){Text("Bayar Sekarang")}
 }}
}

@Composable fun Ticket(f:Flight,home:()->Unit){
 Column{Top("E-Ticket",home);Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
  Card(shape=RoundedCornerShape(24.dp)){Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
   Text("TIKETKU",color=Blue,fontWeight=FontWeight.ExtraBold,fontSize=20.sp)
   Text("Boarding pass",color=Color.Gray)
   Text(f.airline,fontWeight=FontWeight.Bold,fontSize=18.sp)
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(f.from,fontSize=30.sp,fontWeight=FontWeight.Bold);Text(f.depart)};Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.AirplanemodeActive,null,tint=Blue);Text(f.duration,color=Color.Gray)};Column(horizontalAlignment=Alignment.End){Text(f.to,fontSize=30.sp,fontWeight=FontWeight.Bold);Text(f.arrive)}}
   HorizontalDivider()
   Text("Kode booking",color=Color.Gray);Text("TK-${f.code.replace(" ","")}-82A",fontSize=20.sp,fontWeight=FontWeight.Bold)
   Text("STATUS: DEMO",color=Blue,fontWeight=FontWeight.Bold)
  }}
  Button(onClick=home,modifier=Modifier.fillMaxWidth()){Text("Kembali ke Beranda")}
 }}
}
